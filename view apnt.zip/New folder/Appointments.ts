export class Appointments{
    slNo: number;
	Name: string;
	Address: string
	City: string;
	Package: number;
    TrainerPreference: string;
    Phone: number;
    

}