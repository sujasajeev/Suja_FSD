import { Component, OnInit } from '@angular/core';
import { Appointments } from '../Appointments';

@Component({
  selector: 'app-view-apt',
  templateUrl: './view-apt.component.html',
  styleUrls: ['./view-apt.component.css']
})
export class ViewAptComponent implements OnInit {

  // apts: Appointments[];

  constructor(//define obj of service
    ) {
    
  //   this.serviceObject.getApts()
  //   .subscribe(apts =>this.apts=apts);

   }

  ngOnInit(): void {

  }

  
  


}
