package com.egg.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.model.Product;
import com.egg.model.Seller;

import com.egg.dao.SellerRepository;
import com.egg.dao.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	

	@Autowired
	private SellerRepository sellerRepository;

	public String addProduct(Product product, Integer sellerId) {
		Seller s=sellerRepository.getOne(sellerId);//(Seller)
		product.setSeller(s);
		System.out.println(product);
		productRepository.save(product);
		return "\"Product added successfully!\"";
	}
	
	public List<Product> getAllProducts(Integer sellerId){
		return productRepository.getAllProducts(sellerId);
	}
	
	
	
	  public void deleteAll(Integer sellerId) {
	  productRepository.deleteAll(sellerId);
	  
	  }
	 

	public String deleteById(Integer pId) {
		productRepository.deleteById(pId);
		return "Product with productId "+pId+" is deleted.";
	}

	

	
	  public void deleteBySeller(Integer sId, Integer pId) {
	  productRepository.deleteProduct(sId,pId);
	  
	  }

	public Product getProducts(Integer sellerId, Integer productId) {
		return productRepository.getProducts(sellerId,productId);

	}
	
	public Product updateProduct(Product product, Integer pId) {
		Product newProduct = null;
		Optional<Product> prod = productRepository.findById(pId);
		
		if(prod.isPresent()) {
		newProduct = prod.get();
		newProduct.setProductPrice(product.getProductPrice());
		newProduct.setProductName(product.getProductName());
		newProduct.setDescription(product.getDescription());
		newProduct.setStockNumber(product.getStockNumber());
		newProduct.setRemarks(product.getRemarks());

		
		return productRepository.save(newProduct);
		}
		
		return null;
	}

	public List<Product> getMatchingItem(String prodName) {
		return productRepository.getMatchingItem(prodName);
	}

	/*public Product update(Integer sId, Integer pId, Product product) {
		Product newPro = null;
		Optional<Product pro=productRepository.getProducts(sId,pId);
		System.out.println(pro);
		if(pro.isPresent()) {
			newPro = pro.get();
			newPro.setProductPrice(product.getProductPrice());
			newPro.setProductName(product.getProductName());
			newPro.setDescription(product.getDescription());
			newPro.setStockNumber(product.getStockNumber());
			newPro.setRemarks(product.getRemarks());

			
			return productRepository.save(newPro);
			}
		
		return null;*/
	}
	 



