package com.egg.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.model.Category;
import com.egg.dao.CategoryRepository;

@Service
public class CategoryService {
	
	@Autowired
	private CategoryRepository categoryRepository;

	public Optional<Category> findById(Integer cid) {
		
		return categoryRepository.findById(cid);
	}

}
