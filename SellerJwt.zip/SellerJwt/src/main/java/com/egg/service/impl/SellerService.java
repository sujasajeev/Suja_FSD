package com.egg.service.impl;

import java.util.Arrays;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import com.egg.model.Seller;
//import com.emart.repository.ProductRepository;
import com.egg.dao.SellerRepository;

@Service(value = "SellerService")
public class SellerService  implements UserDetailsService {

	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	/*
	 * @Autowired private ProductRepository productRepository;
	 */

	/*
	 * public Seller CreateSeller(Seller seller) {
	 * 
	 * return sellerRepository.save(seller); }
	 */

	/*
	 * public List<Seller> getAllSeller() { return sellerRepository.findAll(); }
	 * 
	 * public Optional<Seller> getSellerById(Integer sellerId) { return
	 * sellerRepository.findById(sellerId); }
	 * 
	 * public void deleteById(Integer sellerId) {
	 * 
	 * Optional<Seller> seller = sellerRepository.findById(sellerId);
	 * 
	 * if (seller.isPresent()) { sellerRepository.deleteById(sellerId); }
	 * 
	 * }
	 * 
	 * public Seller updateSeller(Seller seller) { Optional<Seller> existingSeller =
	 * sellerRepository.findById(seller.getSellerId()); Seller newSeller = null; if
	 * (existingSeller.isPresent()) { newSeller = existingSeller.get();
	 * newSeller.setSellerUsername(seller.getSellerUsername());
	 * newSeller.setSellerPassword(seller.getSellerPassword());
	 * 
	 * newSeller = sellerRepository.save(newSeller); }
	 * 
	 * return newSeller; }
	 */

	public Seller CreateSeller(Seller seller) {
		seller.setSellerPassword(bcryptEncoder.encode(seller.getSellerPassword()));
		return sellerRepository.save(seller);
	}
	
	
public Seller findOne(String username) {
		
		return sellerRepository.findBySellerUsername(username);//findByUsername(username);
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
		}
	

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Seller seller = sellerRepository.findBySellerUsername(username);
				//findBybuyerRepositoryUsername(username);
		if(seller == null){
		throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(seller.getSellerUsername(), seller.getSellerPassword(), getAuthority());
		
	}


	
}
