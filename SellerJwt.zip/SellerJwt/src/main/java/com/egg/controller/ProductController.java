package com.egg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Product;

import com.egg.service.impl.ProductService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;

	// adding a product by seller id
	@PostMapping(value = "/{sid}/addProduct", produces = "application/json") // working
	public String addProduct(@PathVariable("sid") Integer sellerId, @RequestBody Product product) {

		return productService.addProduct(product, sellerId);
	}

	// retrieving all products by seller id
	@GetMapping(value = "/{sid}/getAll") // working
	public List<Product> getAllProducts(@PathVariable("sid") Integer sellerId) {
		return productService.getAllProducts(sellerId);
	}

	// get product by sid,pid
	@GetMapping(value = "/{sid}/{pid}/getAll") // working
	public Product getProducts(@PathVariable("sid") Integer sellerId, @PathVariable("pid") Integer productId) {
		return productService.getProducts(sellerId, productId);
	}

	

	
	// deleting all products by seller id
	@DeleteMapping(value = "/{sid}/deleteall") // working
	public void deleteAll(@PathVariable("sid") Integer sellerId) {
		productService.deleteAll(sellerId);
	}

	// delete product by product id
	@DeleteMapping(value = "/{pid}/deleteproduct") // no need
	public String deleteById(@PathVariable("pid") Integer pId) {
		return productService.deleteById(pId);
	}

	
	// delete by sid,pid
	@DeleteMapping("{sid}/{pid}/deleteById") // working
	public void deleteById(@PathVariable("sid") Integer sId, @PathVariable("pid") Integer pId) {
		productService.deleteBySeller(sId, pId);
	}

	// update product details(p_price,p_name,desc,stock,remarks)
	@PutMapping(value = "{pid}/update", produces = "application/json") // no need
	public Product updateProduct(@RequestBody Product product, @PathVariable("pid") Integer pId) {
		return productService.updateProduct(product, pId);
	}
	
	// update by sid,pid
	/*
	 * @PutMapping("{sid}/{pid}/update") public Product update(@PathVariable("sid")
	 * Integer sId, @PathVariable("pid") Integer pId,@RequestBody Product product){
	 * return productService.update(sId,pId,product);
	 * 
	 * }
	 */
	
	@GetMapping(value = "/search/{name}")//working
	public List<Product> getMatchingItem(@PathVariable("name") String prodName) {
		return productService.getMatchingItem(prodName);
	}


}
