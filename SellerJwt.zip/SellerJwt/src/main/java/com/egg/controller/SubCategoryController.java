package com.egg.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.egg.model.SubCategory;
import com.egg.service.impl.SubCategoryService;

@RestController
@RequestMapping("/subcategory")
public class SubCategoryController {

	@Autowired
	private SubCategoryService subCategoryService;

	@GetMapping(value = "{subid}/get")
	public Optional<SubCategory> findById(@PathVariable("subid") Integer sid) {
		return subCategoryService.findById(sid);

	}

}
