package com.egg.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Category;
import com.egg.model.Seller;
import com.egg.service.impl.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping(value="{catid}/get")
	public Optional<Category> findById(@PathVariable("catid") Integer cid) {
		return categoryService.findById(cid);
		
	}
	
	

}
