package com.emart.contrller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.emart.model.Product;
import com.emart.model.Seller;
import com.emart.service.SellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	private SellerService sellerService;

	@PostMapping(value = "/create", produces = "application/json")//working
	public Seller CreateSeller(@RequestBody Seller seller) {
		return sellerService.CreateSeller(seller);

	}

	@GetMapping(value = "/getAll")//working
	List<Seller> getAllSeller() {
		return sellerService.getAllSeller();
	}

	@GetMapping(value = "/getById/{sid}")//working
	public Optional<Seller> getSellerById(@PathVariable("sid") Integer sellerId) {
		return sellerService.getSellerById(sellerId);
	}

	@RequestMapping(value = "deleteById/{sid}", method = RequestMethod.DELETE)//working
	public void deleteById(@PathVariable("sid") Integer sellerId) {

		sellerService.deleteById(sellerId);
	}

	@PutMapping(value = "/update", produces = "application/json")//working
	public Seller updateSeller(@RequestBody Seller seller) {
		return sellerService.updateSeller(seller);
	}
	
	

}
