package com.emart.contrller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emart.model.Product;
import com.emart.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping(value="/{sid}/addProduct",produces = "application/json")
	public String addProduct(@PathVariable("sid") Integer sellerId,@RequestBody Product product) {
		Optional<Product> savedItem = productService.addProduct(product, sellerId);
		return savedItem.get();
	}
	
	

}
