package com.emart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int sellerId;
	
	@Column
	private String sellerUsername;
	
	@Column
	private String sellerPassword;
	
	@Column
	private String companyName;
	
	@Column
	private long GSTIN;
	
	@Column
	private String aboutCompany;
	
	@Column
	private String postalAddress;
	
	@Column
	private String website;
	
	@Column
	private String emailId;
	
	@Column
	private String contactNumber;
	
	public Seller()
	{
		
	}

	public Seller(int sellerId, String sellerUsername, String sellerPassword, String companyName, long GSTIN,
			String aboutCompany, String postalAddress, String website, String emailId, String contactNumber) {
		
		this.sellerId = sellerId;
		this.sellerUsername = sellerUsername;
		this.sellerPassword = sellerPassword;
		this.companyName = companyName;
		this.GSTIN = GSTIN;
		this.aboutCompany = aboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerUsername() {
		return sellerUsername;
	}

	public void setSellerUsername(String sellerUsername) {
		this.sellerUsername = sellerUsername;
	}

	public String getSellerPassword() {
		return sellerPassword;
	}

	public void setSellerPassword(String sellerPassword) {
		this.sellerPassword = sellerPassword;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	

	public long getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(long gSTIN) {
		GSTIN = gSTIN;
	}

	public String getAboutCompany() {
		return aboutCompany;
	}

	public void setAboutCompany(String aboutCompany) {
		this.aboutCompany = aboutCompany;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
	
	


	

}
