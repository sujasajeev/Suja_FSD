package com.emart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.model.Seller;
import com.emart.repository.SellerRepository;

@Service
public class SellerService {

	@Autowired
	private SellerRepository sellerRepository;

	/*
	 * public Seller CreateSeller(Seller seller) {
	 * 
	 * return sellerRepository.save(seller); }
	 */

	public List<Seller> getAllSeller() {
		return sellerRepository.findAll();
	}

	public Optional<Seller> getSellerById(Integer sellerId) {
		return sellerRepository.findById(sellerId);
	}

	public void deleteById(Integer sellerId) {

		Optional<Seller> seller = sellerRepository.findById(sellerId);

		if (seller.isPresent()) {
			sellerRepository.deleteById(sellerId);
		}

	}

	public Seller updateSeller(Seller seller) {
		Optional<Seller> existingSeller = sellerRepository.findById(seller.getSellerId());
		Seller newSeller = null;
		if (existingSeller.isPresent()) {
			newSeller = existingSeller.get();
			newSeller.setSellerUsername(seller.getSellerUsername());
			newSeller.setSellerPassword(seller.getSellerPassword());

			newSeller = sellerRepository.save(newSeller);
		}

		return newSeller;
	}

	public Seller CreateSeller(Seller seller) {
		// TODO Auto-generated method stub
		return sellerRepository.save(seller);
	}

}
