package com.emart.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.model.Category;
import com.emart.model.SubCategory;
import com.emart.repository.SubCategoryRepository;

@Service
public class SubCategoryService {

	@Autowired
	private SubCategoryRepository subCategoryRepository;

	public Optional<SubCategory> findById(Integer sid) {

		return subCategoryRepository.findById(sid);
	}

}
