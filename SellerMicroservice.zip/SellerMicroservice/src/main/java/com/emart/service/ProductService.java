package com.emart.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.model.Product;
import com.emart.model.Seller;
import com.emart.repository.SellerRepository;
import com.emart.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	

	@Autowired
	private SellerRepository sellerRepository;

	public String addProduct(Product product, Integer sellerId) {
		Seller s=sellerRepository.getOne(sellerId);//(Seller)
		product.setSeller(s);
		System.out.println(product);
		productRepository.save(product);
		return "Product added successfully!";
	}
	
//	@Override
//	public String addItem(int sid, ItemEntity item) {
//	SellerEntity i=sDao.getOne(sid);
//	item.setSeller(i);
//	System.out.println(item);
//	itemDao.save(item);

//	return "item added";
//	}

}
