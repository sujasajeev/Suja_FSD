package com.cts;

public class DemoTryCatch {

	public static void main(String[] args) {
		int i,j,k=0;
		i=8;
		j=0;
		try {
		k=i/j;
		System.out.println(k);
		}
		catch (Exception e)
		{
			System.out.println("Cannot divide by zero  "+e.getMessage());
			//Arithmatic Exception: Unckecked Exception
		}
		System.out.println(k);

	}

}
