package com.cts;

import java.util.Scanner;

public class DemoThrowThrows {

	public static void main(String[] args) throws ArithmeticException {
		//throws:: not to handle exception, to suppress the exception
		int i =0,k=0;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value for j:");
		int j=s.nextInt();
		try
		{
			k=i+j;
			if(k<10)
			{
				throw new ArithmeticException();
				//raising an exception
			}
			
			
		}
		
		finally
		{
			System.out.println("BYE");
		}
		

	}

}
