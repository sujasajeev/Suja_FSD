package com.cts;

public class DemoMultipleCatch {
	public static void main(String[] args) {
	
	int i,j,k = 0;
	
	i=8;
	//j=0;
	j=2;
	int a[]=new int[4];
	try {
	k=i/j;
	for(i=0;i<=4;i++)
	{
		a[i]=i+1;
	}
	System.out.println(k);
	}
	catch (ArithmeticException ae)
	{
		System.out.println("Cannot divide by zero  "+ae.getMessage());
		//Arithmatic Exception: Unchecked Exception
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("Maximum no of entries is 4 "+e.getMessage());
	}
	System.out.println(k);

}

}
