package com.cts;

import java.util.Scanner;

public class DemoFinally {
	public static void main(String[] args) {
		int i =0,k=0;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value for j:");
		int j=s.nextInt();
		try
		{
			k=i/j;
			
			
		}
		catch(ArithmeticException ae)
		{
			System.out.println("You cant divide by Zero  "+ae.getMessage());
		}
		finally
		{
			System.out.println("BYE");
		}
		
	}

}
