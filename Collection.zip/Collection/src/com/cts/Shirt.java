package com.cts;

public class Shirt {
	
	private float price;
	private String colour;
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	
	public Shirt() {
		
	}
	public Shirt(float price, String colour) {
		this.price=price;
		this.colour=colour;
	}
	@Override
	public String toString() {
		return "Shirt [price=" + price + ", colour=" + colour + "]";
	}
	
	}
	


