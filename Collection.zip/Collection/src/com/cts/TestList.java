package com.cts;

import java.util.ArrayList;
import java.util.List;

public class TestList {
	public static void main(String[] args) {
		Shirt shirt1=new Shirt(300.50f,"green");
		Shirt shirt2=new Shirt(500.00f,"red");
		
		
		Watch watch1=new Watch(3000.0f,"titan");
		Watch watch2=new Watch(200.23f,"fasttrack");
		
	//	List<Shirt> cart=new ArrayList();
		
		List cart=new ArrayList();
		cart.add(shirt1);
		cart.add(shirt2);
		/*cart.add(watch1);
		cart.add(watch2);*/
		System.out.println("cart items: "+cart);
		
	}

}
