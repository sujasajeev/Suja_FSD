package com.cts;

import java.util.ArrayList;
import java.util.List;

public class Demo2 {
	
public static void main(String[] args) {
		
		List<Employee> emp = new ArrayList<>();
		emp.add(new Employee(234,"drishya",3459.45,"Architect"));
		emp.add(new Employee(235,"suja",6459.45,".NET Developer"));
		emp.add(new Employee(236,"rekha",3559.45,".NET Developer"));
		System.out.println("list is:"+emp);

}
}
