package com.cts.springmaven.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String getIndexPage() {
		return "index";
	}
	
	
	@RequestMapping("/process.do")
	public String process(@RequestParam("pName") String name, @RequestParam("qty") String quantity,
			@RequestParam("price") String price, Model model) {
		
		model.addAttribute("n",name);
		model.addAttribute("q",quantity);
		model.addAttribute("p",price);
		
		return "result";
	}

}
