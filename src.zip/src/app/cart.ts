export class Cart{
cartId:number;
itemId:number;
itemQuantity:number;
//price:number;
productName:string;
productPrice:number;
}