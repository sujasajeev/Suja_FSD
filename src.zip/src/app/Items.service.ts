import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Itemsearch1 } from './Item';

@Injectable({
    providedIn: 'root'
  })
  export class Itemservice 
  { 
    private baseUrl = 'http://localhost:8082/seller';

    constructor(private http: HttpClient) { }

    getItemByName(Itemsearch1:Object):Observable<any>
    {   
        console.log("in sevie method");
        console.log(Itemsearch1);
        
        return this.http.post(`${this.baseUrl}`+`/search`,Itemsearch1);
    }
  }