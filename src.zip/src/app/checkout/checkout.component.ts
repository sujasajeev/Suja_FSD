import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Transactions } from '../transactions';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {


  constructor(private check:ProductService) { }
   txn:Transactions=new Transactions();
  ngOnInit(): void {
  }

  
checkout(){
  console.log("inside checkout");
  this.check.checkOut(this.txn).subscribe(
    ()=>{alert("Thank you for shopping with Us.")}

  );
}

onSubmit()
  {
    this.checkout();
  }

}
