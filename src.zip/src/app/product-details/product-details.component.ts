import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../items';
import { from } from 'rxjs';
import { ProductService } from '../product.service';
import { Cart } from '../cart';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 
  @Input() 
  item :Item;
  abc:any;
  cart:Cart = new Cart();
 
  constructor(private PService : ProductService ) { }
  
  ngOnInit(): void {
  }

  onSave(itemId : number){
    console.log("inside on save of cart");
    
 this.cart.itemId=this.item.productId;

this.cart.productPrice=this.item.productPrice;

 this.cart.productName=this.item.productName;
 this.cart.itemQuantity=1;
 //this.item.quantity;
    this.PService.addCartItem(this.cart).subscribe(abc=>{
      this.abc=abc;},
      error => console.log('erorr'+error));
      //document.write("added");
     
  }

  

}
