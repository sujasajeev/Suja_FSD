export class Transactions{
    transactionType:string;
}