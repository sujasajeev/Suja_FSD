import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ThankuComponent } from './thanku/thanku.component';
import { TransactionComponent } from './transaction/transaction.component';
import { BuyerComponent } from './buyer/buyer.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {path : 'searchproduct',component:SearchproductComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path:'login',component:LoginComponent},
  {path:'signup',component:SignupComponent},
  {
    path:'checkout',component:CheckoutComponent
  },
  {
    path:'thanku',component:ThankuComponent
  },
  {
    path:'transaction',component:TransactionComponent
  },
  {
    path:'buyer',component:BuyerComponent
  },
  {
    path:'home',component:HomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
