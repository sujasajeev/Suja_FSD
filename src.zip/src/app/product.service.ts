import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart, ApiResponse } from './cart';
import { Buyer } from './signup/buyer';
import { Transactions } from './transactions';


@Injectable(//{
 // providedIn: 'root'
//}
)
export class ProductService {

  private baseUrl = 'http://localhost:8100/product';
  private baseUrl1='http://localhost:8200/cart';
  private baseUrl2='http://localhost:8200/buyer';
  ;


  constructor(private http: HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8200/' + 'token/generate-token', loginPayload);
  }

  getMatchingItem(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/search/${itemname}`);
    //(`${this.baseUrl}/${itemname}`);
  }
  addCartItem(cart:Cart):Observable<ApiResponse> {
return this.http.post<ApiResponse>(`${this.baseUrl1}/1/addcartitem`,cart);


  }

  getAllCartItems() : Observable<any>{

  return this.http.get(`${this.baseUrl1}/1/getAll`);

}

deleteCartItem(cartId:number): Observable<any>{
  return this.http.delete(`${this.baseUrl1}/${cartId}/deletecartitembyid`);
}
emptyCart(): Observable<void>{
  return this.http.delete<void>(`${this.baseUrl1}/1/deleteall`);
}

createBuyer(buyer:Buyer) : Observable<any>
{
console.log("create buyer in server");
return this.http.post(`${this.baseUrl2}/create`,buyer);
}

updateCart(cartId:number,cart:Cart):Observable<any>{
  console.log("update cart service");
  return this.http.put(`${this.baseUrl1}/${cartId}/update`,cart);
}

checkOut(txn:Transactions):Observable<any>
{
  console.log("in checkout server");
  return this.http.post(`${this.baseUrl1}/checkout/1`,txn);
}


}


