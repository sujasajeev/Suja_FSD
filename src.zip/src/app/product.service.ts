import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart } from './cart';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8900/product';
  private baseUrl1='http://localhost:8900/cart';


  constructor(private http: HttpClient) { }

  getMatchingItem(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/search/${itemname}`);
    //(`${this.baseUrl}/${itemname}`);
  }
  addCartItem(cart:Cart):Observable<any> {
return this.http.post(`${this.baseUrl1}/2/addcartitem`,cart);


  }

  getAllCartItems() : Observable<any>{

  return this.http.get(`${this.baseUrl1}/2/getAll`);

}

deleteCartItem(cartId:number): Observable<void>{
  return this.http.delete<void>(`${this.baseUrl1}/${cartId}/deletecartitembyid`);
}
emptyCart(): Observable<void>{
  return this.http.delete<void>(`${this.baseUrl1}/2/deleteall`);
}


}


