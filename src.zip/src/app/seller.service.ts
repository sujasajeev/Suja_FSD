
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SellerService {

  private baseUrl='http://localhost:8700/product';
  //private baseUrl1='http://localhost:8900/cart';

  constructor(private http: HttpClient) {}
  getMatchingItem(name1: string):Observable<any>
  {
    console.log("In service method");
    return this.http.get(`${this.baseUrl}/search/${name1}`);
  }

  //addCartItem(itemId:number): Observable<any>
  //{
    //console.log("Service->addCart");
   // return this.http.post(`${this.baseUrl1}/bid/`)
  //}


}
