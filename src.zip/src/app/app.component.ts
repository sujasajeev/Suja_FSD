import { Component } from '@angular/core';
import { ProductService } from './product.service'
import { from } from 'rxjs';
import { Meta } from '@angular/platform-browser';
import { Item } from './items'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  //ite:Item = new Item();
  searchStr:string;
  items: Item[];
  constructor(private pService:ProductService){

  
console.log("constructor invoked");
  }
  ngOnInit() {
    this.searchStr = "";
   
  }

  search(){
    console.log("invoked search()");
   
    this.pService.getMatchingItem(this.searchStr)
.subscribe(items=>this.items = items);    
  }

 
}
