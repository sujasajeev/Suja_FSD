import { Component } from '@angular/core';
import {Itemservice} from './Items.service';

import {Itemlist} from './Itemsearch';
import { Itemsearch1 } from './Item';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
name:String;
itemsearch : Itemsearch1;
itemlist:Itemlist[];
title="hello-world";

  constructor(private dataService: Itemservice){}
  
  private searchCustomers() {
    this.itemsearch= new Itemsearch1();
    this.itemsearch.prodname="ap";
    console.log("in service method");
    this.dataService.getItemByName(this.itemsearch)
      .subscribe(Itemlist => this.itemlist = Itemlist);
      console.log(this.itemlist);
  }

  onSubmit() {
    console.log("in component.ts");
    this.searchCustomers();
  }
}
