import { Component } from '@angular/core';
import{ SellerService} from './seller.service';
import{Product} from './product'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Seller';
  name1: string;
  storeItem:Product[];

  constructor(private SellerService:SellerService ){
    console.log("constructor invoked");
  }

  ngOnInit(){
    this.name1="";
  }

  met(){
    console.log("invoked met function");
    console.log(this.name1)
    this.SellerService.getMatchingItem(this.name1).subscribe(storeItem=>this.storeItem=storeItem);

  }
}
