import { Component, OnInit } from '@angular/core';
import { Buyer } from './buyer';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private signup:ProductService) { }

  buyer:Buyer =new Buyer();
  ngOnInit(): void {
  }
  addbuyer()
  {
    this.signup.createBuyer(this.buyer).subscribe(buyer=>{alert("your details are saved successfully .")})
  }

  onSubmit()
  {
    this.addbuyer();
  }

}
