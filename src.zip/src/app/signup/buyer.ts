export class Buyer{
	buyerId:number;
    buyerName:string;
	username:string;
	password:string;
    emailId:string;
	mobileNumber:number;
}