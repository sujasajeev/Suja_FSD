export class Buyer{
    buyerName:string;
	username:string;
	password:string;
    emailId:string;
	mobileNumber:number;
}