export class Item {

    
	productId:number;
	categoryId:number;
	subId:number;
	productPrice:number;
	productName:string;
	description:string;
	stockNumber:number;
    remarks:string;
    quantity:number;
	
}




