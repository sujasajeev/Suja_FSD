export class Item {

    
	productId:number;
	categoryId:number;
	subId:number;
	productPrice:string;
	productName:string;
	description:string;
	stockNumber:number;
    remarks:string;
    quantity:number;
	
}


export class Delete {


cartId:number;



}