import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Item } from '../items';

@Component({
  selector: 'app-searchproduct',
  templateUrl: './searchproduct.component.html',
  styleUrls: ['./searchproduct.component.css']
})
export class SearchproductComponent implements OnInit {
  title = 'product';
  
  constructor(private pService:ProductService) { }

  ngOnInit(): void {
   
  }

  
}
