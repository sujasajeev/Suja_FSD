import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { ProductService } from '../product.service';
import { Transactions } from '../transactions';



@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  disCart:Cart[];
  cart:Cart;
  j:any;
  i:any;
  cost:number;
  initialPrice:number;
  txn:Transactions;
  
  //delete:Delete;
 
 count:number;
  constructor(private displaycart:ProductService) {
   
    
   }

  ngOnInit(): void {
    this.cartItems();

}

cartItems(){
  this.displaycart.getAllCartItems().subscribe( disCart => this.disCart=disCart);
  console.log(this.disCart);
}

met(j){
  console.log("inside met");
  //{{this.cart.cartId}}
  console.log(j);
  
  
  this.displaycart.deleteCartItem(j).subscribe(
    ()=>this.cartItems()
   // (disCart => this.disCart=disCart)

     ,(err)=> console.log(err)
    );

}
deleteAll(){
  this.displaycart.emptyCart().subscribe(
    ()=>this.cartItems(),
    (err)=> console.log(err)
  );
}

increment(i,cart){
  if(cart.itemQuantity==1){
    this.initialPrice=cart.productPrice;
  }
 // this.cost=cart.productPrice;
  
     cart.itemQuantity+=1;
     if(cart.itemQuantity>=1){
  cart.productPrice= cart.itemQuantity * this.initialPrice;
  console.log(cart);
  this.displaycart.updateCart(i,cart).subscribe(newview => this.cart=newview);

}
 
}


decrement(i,cart){
  if(cart.itemQuantity==1){
    this.initialPrice=cart.productPrice;
  }
  //this.cost=cart.productPrice;
  
     cart.itemQuantity-=1;
     if(cart.itemQuantity>=1){
  cart.productPrice= cart.itemQuantity *this.initialPrice;
  console.log(cart);
  this.displaycart.updateCart(i,cart).subscribe(newview => this.cart=newview);
}
  

}


}
