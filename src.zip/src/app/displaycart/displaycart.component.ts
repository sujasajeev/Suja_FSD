import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { ProductService } from '../product.service';



@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  disCart:Cart[];
  cart:Cart;
  j:any;
  i:any;
  cost:number;
  
  //delete:Delete;
 
 //count:number;
  constructor(private displaycart:ProductService) {
    this.displaycart.getAllCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
   }

  ngOnInit(): void {
}

met(j){
  console.log("inside met");
  //{{this.cart.cartId}}
  console.log(j);
  
  
  this.displaycart.deleteCartItem(j).subscribe(
    ()=>console.log("deleted")
   // (disCart => this.disCart=disCart)

     ,(err)=> console.log(err)
    );

}
deleteAll(){
  this.displaycart.emptyCart().subscribe(
    ()=>console.log("all deleted"),
    (err)=> console.log(err)
  );
}

increment(i,cart){
  this.cost=cart.productPrice;
  
     cart.itemQuantity+=1;
     if(cart.itemQuantity!=1){
  cart.productPrice= cart.itemQuantity * this.cost;
  console.log(cart);
  
  this.displaycart.updateCart(i,cart).subscribe(newview => this.cart=newview);
}
}

}
