package com.emart.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.model.Buyer;
import com.emart.model.PurchaseHistory;
import com.emart.model.ShoppingCart;
import com.emart.model.Transactions;
import com.emart.repository.BuyerRepository;
import com.emart.repository.CartRepository;
import com.emart.repository.PurchaseRepository;
import com.emart.repository.TransactionRepository;

@Service
public class ShoppingCartService {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
//	public List<ShoppingCart> getAllCartItems(Integer buyerId){
//		return cartRepository.findAllByBuyerId(buyerId);
//	}
	public List<ShoppingCart> getAllCartItems(Integer buyerId){
		return cartRepository.getAllCartItems(buyerId);
	}
	
	public Optional<ShoppingCart> addCartItem(ShoppingCart shoppingCartItem, Integer buyerId//, Integer itemId
			) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyer(buyer);
			//shoppingCartItem.setItemId(itemId);
			
			return cartRepository.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Item with cartId "+cartItemId+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
		
		cartRepository.emptyCart(buyerId);
	}
	
	public ShoppingCart updateCart(ShoppingCart shoppingCartItem,Integer cartItemId) {
		ShoppingCart newCart = null;
		Optional<ShoppingCart> cartItem = cartRepository.findById(cartItemId);
		
		if(cartItem.isPresent()) {
		newCart = cartItem.get();
		newCart.setItemQuantity(shoppingCartItem.getItemQuantity());
		newCart.setProductPrice(shoppingCartItem.getProductPrice());
		
		return cartRepository.save(newCart);
		}
		
		return null;
		
	}
	
	
	
	public String checkOut(Transactions transactions, int buyerid) {
		//System.out.println("hiiii");
		Buyer buyer=buyerRepository.getOne(buyerid);
		System.out.println(buyer);
		transactions.setBuyerId(buyer);//transaction table and buyer relation
		System.out.println(transactions);
		transactionRepository.save(transactions);
		
		List<ShoppingCart> sCart=cartRepository.getById(buyerid);
		for(int i=0;i<sCart.size();i++)
		{	
			PurchaseHistory pHistory=new PurchaseHistory();
			ShoppingCart scItem=sCart.get(i);
			int noOfItem=scItem.getItemQuantity();
			
			pHistory.setNumberOfItems(noOfItem);
			int itemId=scItem.getItemId();
			pHistory.setItemId(itemId);
			pHistory.setBuyer(buyer);
			System.out.println(scItem);
			cartRepository.deleteById(scItem.getCartId());
			purchaseRepository.save(pHistory);
		}
		
		return "Visit again";
	}

	

}
