package com.emart.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "purchase_history")
public class PurchaseHistory implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "purchase_id")
	private int purchaseId;
	
	@ManyToOne
	@JoinColumn(name = "buyerId")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyer;
	
	/*
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "transactionId")
	 * 
	 * @OnDelete(action = OnDeleteAction.CASCADE) private Transactions transactions;
	 */
	
	
	 @Column private int itemId;
	 
	
	@Column
	private int numberOfItems;
	
	
	@CreationTimestamp
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date createdOn;
	
	/*
	 * @Column private String purchaseRemarks;
	 */
	
	public PurchaseHistory() {
		// TODO Auto-generated constructor stub
	}

	public PurchaseHistory(int purchaseId, Buyer buyer, /*Transactions transactions,*/
			int itemId, int numberOfItems, Date createdOn/* , String purchaseRemarks */) {

		this.purchaseId = purchaseId;
		this.buyer = buyer;
		//this.transactions = transactions;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.createdOn = createdOn;
		//this.purchaseRemarks = purchaseRemarks;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public Buyer getBuyer() {
		return buyer;
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	/*
	 * public Transactions getTransactions() { return transactions; }
	 * 
	 * public void setTransactionHistory(Transactions transactions) {
	 * this.transactions = transactions; }
	 */
	
	public int getItemId() {
		return itemId;
	}
	
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/*
	 * public String getPurchaseRemarks() { return purchaseRemarks; }
	 * 
	 * public void setPurchaseRemarks(String purchaseRemarks) { this.purchaseRemarks
	 * = purchaseRemarks; }
	 */
	
	

	

}
