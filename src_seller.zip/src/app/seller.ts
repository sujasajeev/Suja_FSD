export class Seller{
   
	 sellerUsername:string;
	
	 sellerPassword:string;
	
    companyName:string;
	
	gstin:number;
	
	aboutCompany:string;
	
	postalAddress:string;
	
	 website:string;
	
	emailId:string;
	
contactNumber:string;
}