import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Seller } from './seller';
import { Observable } from 'rxjs';
import { Product, ApiResponse } from './product';

@Injectable({
  providedIn: 'root'
})
export class SellerService {
  private baseUrl = 'http://localhost:8100/product';
  private baseUrl1 = 'http://localhost:8100/seller';

  constructor(private http: HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8100/' + 'token/generate-token', loginPayload);
  }

  CreateSeller(seller:Seller) : Observable<any>
  {
    console.log("create seller in server");
    return this.http.post(`${this.baseUrl1}/create`,seller);
  }

  addProduct(product:Product):Observable<any>{

    console.log("create product in server");
    return this.http.post(`${this.baseUrl}/1/addProduct`,product);
  }

  getAllProducts():Observable<any>{
    console.log("disolay product in server");
    return this.http.get(`${this.baseUrl}/1/getAll`);

  }
  deleteById(pid:number):Observable<any>{
    return this.http.delete(`${this.baseUrl}/${pid}/deleteproduct`);
  }

  


}
