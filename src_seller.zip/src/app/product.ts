export class Product {

    
	productId:number;
	categoryId:number;
	subId:number;
	productPrice:number;
	productName:string;
	description:string;
	stockNumber:number;
    remarks:string;
   
	
}

export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }

  export class User {

    id: number;
  
  }
  