import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { DisplayproductsComponent } from './displayproducts/displayproducts.component';
import { EditproductComponent } from './editproduct/editproduct.component';


const routes: Routes = [
  {
    path:'login',component:LoginComponent
  },
  {
    path:'signup',component:SignupComponent
  },
  {
    path:'addproduct',component:AddproductComponent
  },
  {
    path:'displayproducts',component:DisplayproductsComponent
  },
  {
    path:'editproduct',component:EditproductComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
