import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {

  constructor() { }
  
  pdct:Product[];

  ngOnInit(): void {
  }

}
