import { Component, OnInit } from '@angular/core';
import { SellerService } from '../seller.service';
import { Seller } from '../seller';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private signup:SellerService) { }
  seller:Seller =new Seller();

  ngOnInit(): void {
  }

  addseller()
  {
    this.signup.CreateSeller(this.seller).subscribe(seller=>{alert("your details are saved successfully .")})
  }

  onSubmit()
  {
    console.log("inside on submit");
    this.addseller();
  }

}
