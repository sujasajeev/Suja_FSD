import { Component, OnInit } from '@angular/core';
import { SellerService } from '../seller.service';
import { Product } from '../product';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  constructor(private addproduct:SellerService) { }

  product:Product = new Product();

  ngOnInit(): void {
  }

  add()
  {
    this.addproduct.addProduct(this.product).subscribe(product=>{alert("product details are saved successfully .")})
  }

  onSubmit()
  {
    console.log("inside on submit");
    this.add();
  }


}
