import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { SellerService } from '../seller.service';

@Component({
  selector: 'app-displayproducts',
  templateUrl: './displayproducts.component.html',
  styleUrls: ['./displayproducts.component.css']
})
export class DisplayproductsComponent implements OnInit {

  pdct:Product[];
  j:any;

  constructor(private displayproducts:SellerService) { }

  ngOnInit(): void {
    this.display();

  }

  display(){
    console.log("inside display");
    this.displayproducts.getAllProducts().subscribe( pdct => this.pdct=pdct);
  console.log(this.pdct);
  }

  delete(j){

    console.log("inside delete");
    //{{this.cart.cartId}}
    console.log(j);
    
    
    this.displayproducts.deleteById(j).subscribe(
      ()=>this.display()
     // (disCart => this.disCart=disCart)
  
       ,(err)=> console.log(err)
      );

  }

}
