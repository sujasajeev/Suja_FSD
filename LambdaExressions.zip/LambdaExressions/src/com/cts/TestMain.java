package com.cts;

import java.util.ArrayList;

public class TestMain {
	
	    public static void main(String args[]) 
	    { 
	        // Creating an ArrayList with elements {1, 2, 3, 4} 
	        ArrayList<Integer> arrayList = new ArrayList<Integer>(); 
	        arrayList.add(1); 
	        arrayList.add(2); 
	        arrayList.add(3); 
	        arrayList.add(4); 
	  
	        // Using lambda expression to print all elements 
	        // of arrL 
	        arrayList.forEach(n -> System.out.println(n)); 
	  
	        // Using lambda expression to print even elements 
	        // of arrL 
	        arrayList.forEach(n -> { if (n%2 == 0) System.out.println(n); }); 
	    } 
	} 


