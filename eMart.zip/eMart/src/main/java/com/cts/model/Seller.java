package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Seller implements Serializable {
	
	@Id
	private int sellerId;
	private String sellerUserName;
	private String sellerPassWord;
	private String companyName;
	private String GSTIN;
	private String briefAboutCompany;
	private String postalAddress;
	private String website;
	private String buyerEmailId;
	private String buyerMobileNumber;
	
	public Seller()
	{
		
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerUserName() {
		return sellerUserName;
	}

	public void setSellerUserName(String sellerUserName) {
		this.sellerUserName = sellerUserName;
	}

	public String getSellerPassWord() {
		return sellerPassWord;
	}

	public void setSellerPassWord(String sellerPassWord) {
		this.sellerPassWord = sellerPassWord;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}

	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}

	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getBuyerEmailId() {
		return buyerEmailId;
	}

	public void setBuyerEmailId(String buyerEmailId) {
		this.buyerEmailId = buyerEmailId;
	}

	public String getBuyerMobileNumber() {
		return buyerMobileNumber;
	}

	public void setBuyerMobileNumber(String buyerMobileNumber) {
		this.buyerMobileNumber = buyerMobileNumber;
	}

	public Seller(int sellerId, String sellerUserName, String sellerPassWord, String companyName, String gSTIN,
			String briefAboutCompany, String postalAddress, String website, String buyerEmailId,
			String buyerMobileNumber) {
		
		this.sellerId = sellerId;
		this.sellerUserName = sellerUserName;
		this.sellerPassWord = sellerPassWord;
		this.companyName = companyName;
		GSTIN = gSTIN;
		this.briefAboutCompany = briefAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.buyerEmailId = buyerEmailId;
		this.buyerMobileNumber = buyerMobileNumber;
	}

	@Override
	public String toString() {
		return "Seller [sellerId=" + sellerId + ", sellerUserName=" + sellerUserName + ", sellerPassWord="
				+ sellerPassWord + ", companyName=" + companyName + ", GSTIN=" + GSTIN + ", briefAboutCompany="
				+ briefAboutCompany + ", postalAddress=" + postalAddress + ", website=" + website + ", buyerEmailId="
				+ buyerEmailId + ", buyerMobileNumber=" + buyerMobileNumber + "]";
	}
	
	
	
	
	
	
	

}
