package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Items implements Serializable {
	@Id
	private int itemId;
	private float price;
	private String itemName;
	private String description;
	private int stockNumber;
	private String Remarks;
	
	public Items()
	{
		
	}

	public Items(int itemId, float price, String itemName, String description, int stockNumber, String remarks) {
		
		this.itemId = itemId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		Remarks = remarks;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", price=" + price + ", itemName=" + itemName + ", description="
				+ description + ", stockNumber=" + stockNumber + ", Remarks=" + Remarks + "]";
	}
	
	

}
