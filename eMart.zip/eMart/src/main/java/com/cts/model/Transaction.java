package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction implements Serializable {
	 
	@Id
	private int transactionId;
	private String transactionType;
	private String dateTime;
	private String remarks;
	
	public Transaction()
	{
		
	}

	public Transaction(int transactionId, String transactionType, String dateTime, String remarks) {
		
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType + ", dateTime="
				+ dateTime + ", remarks=" + remarks + "]";
	}
	
	
	
	

}
