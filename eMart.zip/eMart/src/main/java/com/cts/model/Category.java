package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Category implements Serializable  {
	
	@Id
	private int categoryId;
	private String categoryName;
	private String briefDetails;
	
	public Category()
	{
		
	}

	public Category(int categoryId, String categoryName, String briefDetails) {
		
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.briefDetails = briefDetails;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getBriefDetails() {
		return briefDetails;
	}

	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", briefDetails="
				+ briefDetails + "]";
	}
	
	

}
