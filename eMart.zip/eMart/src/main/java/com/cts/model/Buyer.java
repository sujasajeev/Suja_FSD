package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Buyer implements Serializable  {
	
	
	@Id
	private int buyerId;
	private String buyerUserName;
	private String buyerPassWord;
	private String buyerEmailId;
	private String buyerMobileNumber;
	private String buyerDateTime;
	
	
	public Buyer()
	{
		System.out.println("Object of buyer created");
	}

	public Buyer(int buyerId, String buyerUserName, String buyerPassWord, String buyerEmailId, String buyerMobileNumber,
			String buyerDateTime, String userName) {
	
		this.buyerId = buyerId;
		this.buyerUserName = buyerUserName;
		this.buyerPassWord = buyerPassWord;
		this.buyerEmailId = buyerEmailId;
		this.buyerMobileNumber = buyerMobileNumber;
		this.buyerDateTime = buyerDateTime;
		
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerUserName() {
		return buyerUserName;
	}

	public void setBuyerUserName(String buyerUserName) {
		this.buyerUserName = buyerUserName;
	}

	public String getBuyerPassWord() {
		return buyerPassWord;
	}

	public void setBuyerPassWord(String buyerPassWord) {
		this.buyerPassWord = buyerPassWord;
	}

	public String getBuyerEmailId() {
		return buyerEmailId;
	}

	public void setBuyerEmailId(String buyerEmailId) {
		this.buyerEmailId = buyerEmailId;
	}

	public String getBuyerMobileNumber() {
		return buyerMobileNumber;
	}

	public void setBuyerMobileNumber(String buyerMobileNumber) {
		this.buyerMobileNumber = buyerMobileNumber;
	}

	public String getBuyerDateTime() {
		return buyerDateTime;
	}

	public void setBuyerDateTime(String buyerDateTime) {
		this.buyerDateTime = buyerDateTime;
	}

	@Override
	public String toString() {
		return "Buyer [buyerId=" + buyerId + ", buyerUserName=" + buyerUserName + ", buyerPassWord=" + buyerPassWord
				+ ", buyerEmailId=" + buyerEmailId + ", buyerMobileNumber=" + buyerMobileNumber + ", buyerDateTime="
				+ buyerDateTime + "]";
	}
	
	

	


}
