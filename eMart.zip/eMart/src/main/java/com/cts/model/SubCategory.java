package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SubCategory implements Serializable {
	
	@Id
	private int subCategoryId;
	private String subCtegoryName;
	private String briefDetails;
	private float GST;
	
	public SubCategory()
	{
		
	}

	public SubCategory(int subCategoryId, String subCtegoryName, String briefDetails, float gST) {
	
		this.subCategoryId = subCategoryId;
		this.subCtegoryName = subCtegoryName;
		this.briefDetails = briefDetails;
		GST = gST;
	}

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCtegoryName() {
		return subCtegoryName;
	}

	public void setSubCtegoryName(String subCtegoryName) {
		this.subCtegoryName = subCtegoryName;
	}

	public String getBriefDetails() {
		return briefDetails;
	}

	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}

	public float getGST() {
		return GST;
	}

	public void setGST(float gST) {
		GST = gST;
	}

	@Override
	public String toString() {
		return "SubCategory [subCategoryId=" + subCategoryId + ", subCtegoryName=" + subCtegoryName + ", briefDetails="
				+ briefDetails + ", GST=" + GST + "]";
	}
	
	
	

}
