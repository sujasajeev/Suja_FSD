package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PurchaseHistory implements Serializable {
	
	@Id
	private int purchaseId;
	private int numberOfItems;
	private int dateTime;
	private String remarks;
	
	public PurchaseHistory()
	{
		
	}

	public PurchaseHistory(int purchaseId, int numberOfItems, int dateTime, String remarks) {
		
		this.purchaseId = purchaseId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public int getDateTime() {
		return dateTime;
	}

	public void setDateTime(int dateTime) {
		this.dateTime = dateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseId=" + purchaseId + ", numberOfItems=" + numberOfItems + ", dateTime="
				+ dateTime + ", remarks=" + remarks + "]";
	}
	
	
}
