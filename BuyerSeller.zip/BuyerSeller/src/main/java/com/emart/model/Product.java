package com.emart.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


@Entity
@Table(name="product")
public class Product implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int productId;
	
	private int categoryId;
	private int subId;
	
	
	
	@ManyToOne
	@JoinColumn(name="seller_id")
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Seller seller;
	
	private float productPrice;
	private String productName;
	private String description;
	private int stockNumber;
	private String remarks;
	
	public Product() {
		
	}

	public Product(int productId, int categoryId, int subId, Seller seller, float productPrice, String productName,
			String description, int stockNumber, String remarks) {
		
		this.productId = productId;
		this.categoryId = categoryId;
		this.subId = subId;
		this.seller = seller;
		this.productPrice = productPrice;
		this.productName = productName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSubId() {
		return subId;
	}

	public void setSubId(int subId) {
		this.subId = subId;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public float getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
	
	
	
	


}
