package com.emart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="sub_category")
public class SubCategory implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int subId;
	
	@Column
	private String subName;
	
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category category;
	
	@Column
	private String description;
	
	@Column
	private float gst;
	
	public SubCategory() {
		
	}

	public SubCategory(int subId, String subName, Category category, String description, float gst) {
	
		this.subId = subId;
		this.subName = subName;
		this.category = category;
		this.description = description;
		this.gst = gst;
	}

	public int getSubId() {
		return subId;
	}

	public void setSubId(int subId) {
		this.subId = subId;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getGst() {
		return gst;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}
	
	
	
	



}
