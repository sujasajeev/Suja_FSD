package com.emart.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.emart.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

	@Query(value = "SELECT * FROM product p WHERE p.seller_id = :sellerId", nativeQuery = true)
	public List<Product> getAllProducts(@Param("sellerId") Integer sellerId);

	@Transactional

	@Modifying

	@Query(value = "DELETE FROM product  WHERE product.seller_id = :sellerId", nativeQuery = true)
	public void deleteAll(@Param("sellerId") Integer sellerId);

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM product  WHERE product.seller_id = :sId AND product.product_id = :pId", nativeQuery = true)
	public void deleteProduct(@Param("sId") Integer sellerId, @Param("pId") Integer productId);

	@Query(value = "SELECT * FROM product WHERE product.seller_id=:sellerId AND product.product_id=:productId", nativeQuery = true)
	public Product getProducts(Integer sellerId, Integer productId);

	
	@Query(value="SELECT * FROM product WHERE product.product_name like %:prodName%", nativeQuery = true)
	public List<Product> getMatchingItem(String prodName);

}
