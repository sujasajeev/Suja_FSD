package com.cts.hibernate.main;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Employee;

public class TestHibernate {

	public static void main(String[] args) {
		
		
		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session= sf.openSession();
		
		
		/*
		 * Employee emp1=new Employee(1001,"Ajay","Manager");
		 * session.beginTransaction(); Serializable ob=session.save(emp1);
		 * session.getTransaction().commit(); session.close();
		 */		
		
		/*
		 * Employee emp=new Employee(1003,"Matt","Manager"); session.beginTransaction();
		 * Serializable ob=session.save(emp);//managed
		 * emp.setEmployeeDesignation("Sr mgr"); session.getTransaction().commit();
		 * session.close();
		 */
    	
    	
    	Employee e=(Employee)session.get(Employee.class,1003);
    	System.out.println(e);//since we used get() method, the object is in managed state
    	session.evict(e);
    	session.beginTransaction(); 
    	session.update(e);
    	e.setEmployeeDesignation("updatedManager");
    	 session.getTransaction().commit();
    	 session.close();
    	
    	//System.out.println(e);
    	//session.save(e); // constraint violation in PK
    	//session.update(e);
    	//session.flush();
   // 	session.flush();
       	//session.getTransaction().commit();
    	

	}

}
