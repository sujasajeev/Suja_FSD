package com.egg.service.impl;

import org.springframework.stereotype.Service;

@Service
public class PurchaseService {
	
	
	
}
