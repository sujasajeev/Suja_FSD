package com.egg.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "cart")
public class ShoppingCart implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int cartId;
	
	@Column
	private int itemId;
	
	@Column
	private String productName;
	
	@Column
	private float productPrice;
	
	
	//@Column(columnDefinition = "int default 1")
	@Column//(columnDefinition = " default '1'")
	private int itemQuantity;
	
	@ManyToOne
	@JoinColumn(name = "buyerId")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyer;
	

	public ShoppingCart() {
		
	}


	public ShoppingCart(int cartId, int itemId, String productName, float productPrice, int itemQuantity,
			Buyer buyer) {
		super();
		this.cartId = cartId;
		this.itemId = itemId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.itemQuantity = itemQuantity;
		this.buyer = buyer;
	}


	public int getCartId() {
		return cartId;
	}


	public void setCartId(int cartId) {
		this.cartId = cartId;
	}


	public int getItemId() {
		return itemId;
	}


	public void setItemId(int itemId) {
		this.itemId = itemId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public float getProductPrice() {
		return productPrice;
	}


	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}


	public int getItemQuantity() {
		return itemQuantity;
	}


	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}


	public Buyer getBuyer() {
		return buyer;
	}


	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}


	

	
	


	
	
}
