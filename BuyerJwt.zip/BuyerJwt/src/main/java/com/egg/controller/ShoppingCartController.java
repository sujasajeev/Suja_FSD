package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ShoppingCart;
import com.egg.model.Transactions;
import com.egg.service.impl.ShoppingCartService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/cart")
public class ShoppingCartController {
	
	@Autowired
	private ShoppingCartService cartService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<ShoppingCart> getAllCartItems(@PathVariable("bid")Integer buyerId) {
	return cartService.getAllCartItems(buyerId);
	}
	
	@PostMapping(value="/{bid}/addcartitem",produces = "application/json")
	public ShoppingCart addCartItem(@PathVariable("bid") Integer buyerId//,@PathVariable("iid") Integer itemId
			,@RequestBody ShoppingCart shoppingCartItem) {
		Optional<ShoppingCart> savedItem = cartService.addCartItem(shoppingCartItem, buyerId//,itemId
				);
		return savedItem.get();
	}
	
	@DeleteMapping(value = "/{cartitem}/deletecartitembyid")
	public String deleteCartItem(@PathVariable("cartitem") Integer cartItemId) {
		return cartService.deleteCartItemById(cartItemId);
	}
	
	@DeleteMapping(value = "/{bid}/deleteall")
	public void emptyCart(@PathVariable("bid") Integer buyerId) {
		cartService.emptyCart(buyerId);
	}
	
	@PutMapping(value = "/{cartid}/update",produces = "application/json")
	public ShoppingCart updateCart(@RequestBody ShoppingCart shoppingCartItem,@PathVariable("cartid") Integer cartItemId) {
		return cartService.updateCart(shoppingCartItem, cartItemId);
	}
	
	@PostMapping("/checkout/{bid}")
	public String checkOut(@RequestBody Transactions transactions,@PathVariable("bid") int buyerid)
	{
		return cartService.checkOut(transactions,buyerid);
	}
}
