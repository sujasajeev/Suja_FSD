package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.Transactions;

public interface TransactionRepository extends JpaRepository<Transactions, Long>{

}
