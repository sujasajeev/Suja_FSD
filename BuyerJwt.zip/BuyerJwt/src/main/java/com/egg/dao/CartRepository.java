package com.egg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.ShoppingCart;

@Repository
public interface CartRepository extends JpaRepository<ShoppingCart, Integer>{

	  @Transactional
	  @Modifying
	  @Query(value = "DELETE FROM cart  WHERE cart.buyerId = :buyerId" ,nativeQuery= true) 
	  public void emptyCart(@Param("buyerId")Integer buyerId);
	 
	
	
	
	@Query(value = "SELECT * FROM cart  WHERE cart.buyerId = :buyerId"
			,nativeQuery = true)
	public List<ShoppingCart> getAllCartItems(@Param("buyerId")Integer buyerId);
	
	//used when checkout
	@Query(value="SELECT * FROM cart WHERE cart.buyerId = :buyer",nativeQuery = true)
	public List<ShoppingCart> getById(@Param("buyer") int buyerid);
		
	
}
