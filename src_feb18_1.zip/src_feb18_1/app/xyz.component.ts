import { Component } from '@angular/core';

@Component({
    selector: 'app-xyz',
    template: `<h2>xyz</h2>`
  })
  export class XyzComponent { }